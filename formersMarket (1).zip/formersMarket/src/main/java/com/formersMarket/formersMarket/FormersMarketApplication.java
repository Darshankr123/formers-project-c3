package com.formersMarket.formersMarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormersMarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormersMarketApplication.class, args);
	}

}
